<?php
include './includes/config.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $for = $_POST['for'];

    $message = $pass;

    if ($for == "user") {
        $sql = "SELECT id,password from users where email = ?";
        $url = './user_pages/index.php';
    } else if ($for == "doctor") {
        $sql = "SELECT id,password from doctors where email = ?";
        $url = './doctor_pages/index.php';
    } else {
        $sql = "SELECT id,password from admins where email = ?";
        $url = './admin_pages/index.php';
    }


    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->bind_result($id, $hashed_password);
    $stmt->fetch();
    $stmt->close();

    if ($id != null and $hashed_password != null) {

        if (password_verify($pass, $hashed_password)) {
            $_SESSION['uid'] = $id;
            header("Location: $url");
        } else {
            $message = "Invalid Password";
        }
    } else {
        $message = "No email id found";
    }
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background-image: url('./includes/images/bg_1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            backdrop-filter: blur(10px);
            min-height: 100vh;
        }
    </style>
    <title>Login</title>
</head>

<body>
    <?php include './includes/header.php' ?>

    <div class="container shadow p-3 mb-5 bg-body rounded" style="width: 360px;margin-top:150px">
        <h3 class="text-center nav-pills nav-fill">
            <div class="nav-item">
                <div class="nav-link active bg-dark">Login</div>
            </div>
        </h3>
        <form action="" method="post" style="display: flex;flex-direction:column;">
            <div class="mb-3">
                <label for="selection" class="form-label">Login as</label>
                <select class="form-select" name="for" id="selection" aria-label="Default select example">
                    <option value="user">User</option>
                    <option value="doctor">Doctor</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1">
            </div>
            <p style="color: red;"><?php echo $message; ?></p>
            <button type="submit" class="btn btn-dark" style="align-self: center;">Submit</button>
            <div class="text-center" style="margin-top: 10px;">
                <p>Don't have an account? <a href="./register.php">Register</a></p>
            </div>
        </form>
    </div>
    <?php include './includes/footer2.php' ?>

</body>

</html>