<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
</head>

<body>

    <div class="container" style="max-width: 100% !important;">
        <footer class="footer bg-dark" id="contactUs" style="padding: 60px 40px;">
            <div class="container text-light">
                <div class="row">
                    <div class="col-md-6">
                        <h5>Contact Information</h5>
                        <p><i class="fa fa-map-marker" style="width:30px"></i>123 Yelahanka ,Banglore-123456</p>
                        <p><i class="fa fa-envelope" style="width:30px"></i>Email: info@healthcareapp.com</p>
                        <p><i class="fa fa-phone" style="width:30px"></i>Phone: +91 123456789</p>
                    </div>
                    <div class="col-md-6 text-md-right">
                        <h5>Message Us</h5>
                        <form method="post" action="">
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label for="messageEmail">Name</label>
                                <input type="text" name="name" class="form-control" id="messageEmail" placeholder="Enter your name">
                            </div>
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label for="messageEmail">Email address</label>
                                <input type="email" name="email" class="form-control" id="messageEmail" placeholder="Enter your email">
                            </div>
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label for="messageText">Message</label>
                                <textarea class="form-control" name="message" id="messageText" rows="3" placeholder="Your message"></textarea>
                            </div>
                            <p class="<?php
                                        if ($success)
                                            echo 'text-success';
                                        else
                                            echo 'text-danger';
                                        ?>"><?php echo $message; ?></p>
                            <button type="submit" name="submit" class="btn btn-light">Send</button>
                        </form>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</body>

</html>