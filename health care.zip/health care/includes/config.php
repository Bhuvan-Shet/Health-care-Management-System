<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "healthcare_database";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection error : " . $conn->connect_error);
}

if (!isset($_SESSION)) {
    session_start();
}
