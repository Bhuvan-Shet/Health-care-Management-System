-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2024 at 08:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcare_database`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ApproveAppointment` (IN `p_temp_appointment_id` INT, IN `p_appointment_date` DATE)   BEGIN
    DECLARE v_doctor_id INT;
    DECLARE v_user_id INT;
    DECLARE v_token_number INT;

    -- Get doctor_id and user_id from temporary_appointments
    SELECT doctor_id, user_id INTO v_doctor_id, v_user_id
    FROM temporary_appointments
    WHERE temp_appointment_id = p_temp_appointment_id;

    -- Generate the next token number for the doctor on the appointment_date
    SELECT IFNULL(MAX(token_number), 0) + 1 INTO v_token_number
    FROM appointments
    WHERE doctor_id = v_doctor_id
      AND appointment_time = p_appointment_date;

    -- Insert into appointments table
    INSERT INTO appointments (doctor_id, user_id, token_number, appointment_time,status)
    VALUES (v_doctor_id, v_user_id, v_token_number, p_appointment_date,'pending');

    -- Update the status in temporary_appointments
    UPDATE temporary_appointments
    SET status = 'approved'
    WHERE temp_appointment_id = p_temp_appointment_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `approveDoctor` (IN `p_req_doctor_id` INT)   BEGIN
    DECLARE v_fullname VARCHAR(100);
    DECLARE v_email VARCHAR(100);
    DECLARE v_password VARCHAR(255);
    DECLARE v_phone VARCHAR(15);
    DECLARE v_specialization VARCHAR(100);
    DECLARE v_qualifications VARCHAR(255);
    DECLARE v_gender VARCHAR(10);
    DECLARE v_BMDC_reg_num VARCHAR(50);
    DECLARE v_address VARCHAR(255);

    -- Fetch the record from req_doctors
    SELECT fullname, email, password, phone, specialization, qualifications, gender, BMDC_reg_num, address
    INTO v_fullname, v_email, v_password, v_phone, v_specialization, v_qualifications, v_gender, v_BMDC_reg_num, v_address
    FROM req_doctors
    WHERE id = p_req_doctor_id;

    -- Insert the record into doctors
    INSERT INTO doctors (fullname, email, password, phone, specialization, qualifications, gender, BMDC_reg_num, address)
    VALUES (v_fullname, v_email, v_password, v_phone, v_specialization, v_qualifications, v_gender, v_BMDC_reg_num, v_address);

    -- Delete the record from req_doctors
    DELETE FROM req_doctors WHERE id = p_req_doctor_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DenyAppointment` (IN `p_temp_appointment_id` INT, IN `p_reason` VARCHAR(255))   BEGIN
    DECLARE v_doctor_id INT;
    DECLARE v_user_id INT;
    DECLARE v_request_time DATE;
    DECLARE v_denied_time DATE;

    -- Get doctor_id, user_id, and request_time from temporary_appointments
    SELECT doctor_id, user_id, request_time INTO v_doctor_id, v_user_id, v_request_time
    FROM temporary_appointments
    WHERE temp_appointment_id = p_temp_appointment_id;

    -- Get the current time as denied_time
    SET v_denied_time = NOW();

    -- Insert into denied_appointments table
    INSERT INTO denied_appointments (doctor_id, user_id, request_time, denied_time, reason)
    VALUES (v_doctor_id, v_user_id, v_request_time, v_denied_time, p_reason);

    -- Update the status in temporary_appointments
    UPDATE temporary_appointments
    SET status = 'denied'
    WHERE temp_appointment_id = p_temp_appointment_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GenerateToken` (IN `p_doctor_id` INT, OUT `p_token_number` INT)   BEGIN
    DECLARE max_token INT;
    
    SELECT IFNULL(MAX(token_number), 0) + 1 INTO max_token
    FROM appointments
    WHERE doctor_id = p_doctor_id;
    
    SET p_token_number = max_token;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateExpiredAppointments` ()   BEGIN
    UPDATE appointments
    SET status = 'expired'
    WHERE appointment_time < CURDATE() AND status = 'pending';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$UHPtf4eocxKw5zruY6naEu4lbok9OQ6HoDqZUtcwGpXBEn3t1Or4O');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `token_number` int(11) DEFAULT NULL,
  `appointment_time` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `doctor_id`, `user_id`, `token_number`, `appointment_time`, `status`) VALUES
(13, 1, 2, 1, '2024-06-08', 'expired'),
(14, 1, 2, 2, '2024-06-15', 'expired'),
(15, 1, 2, 1, '2024-06-16', 'expired'),
(16, 2, 11, 1, '2024-06-27', 'pending'),
(17, 1, 2, 1, '2024-06-17', 'pending'),
(18, 1, 11, 1, '2024-06-05', 'expired');

--
-- Triggers `appointments`
--
DELIMITER $$
CREATE TRIGGER `before_appointment_insert` BEFORE INSERT ON `appointments` FOR EACH ROW BEGIN
    DECLARE v_token_number INT;

    -- Generate the next token number for the doctor on the appointment_date
    SELECT IFNULL(MAX(token_number), 0) + 1 INTO v_token_number
    FROM appointments
    WHERE doctor_id = NEW.doctor_id
      AND appointment_time = NEW.appointment_time;

    -- Set the token_number for the new appointment
    SET NEW.token_number = v_token_number;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `denied_appointments`
--

CREATE TABLE `denied_appointments` (
  `denied_appointment_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `request_time` date DEFAULT NULL,
  `denied_time` date DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `denied_appointments`
--

INSERT INTO `denied_appointments` (`denied_appointment_id`, `doctor_id`, `user_id`, `request_time`, `denied_time`, `reason`) VALUES
(1, 1, 11, '2024-06-11', '2024-06-17', 'Doctor is unavailable at the requested time.');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `qualifications` varchar(255) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `BMDC_reg_num` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `fullname`, `email`, `password`, `phone`, `specialization`, `qualifications`, `gender`, `BMDC_reg_num`, `address`) VALUES
(1, 'Amit Patel', 'AmitPatel@gmail.com', '$2y$10$I2RvPF3rSjT1z3crEkgqROXtPk7oCD6rjCVynTs.ZvPWKCqxfJRkK', '9876543210', 'Cardiology', 'MBBS, MD', 'male', 'BMDC12345', '123 Main St'),
(2, 'Rajesh Kumar', 'RajeshKumar@gmail.com', '$2y$10$pgn0udprcrODEwIdqpYt1upolXJaBsfzojUOmabr9iLNGsK5iF1Mu', '9876543212', 'Orthopedics', 'MBBS, MS', 'male', 'BMDC12346', '124 Main St'),
(3, 'Vijay Reddy', 'VijayReddy@gmail.com', '$2y$10$ekCkcWV6.Sm74/m8bunnAuvF5W6f2bbzA.9ruYX.QloXf5q/Ri4c2', '9876543214', 'Dermatology', 'MBBS, DDVL', 'male', 'BMDC12347', '125 Main St'),
(4, 'Ravi Verma', 'RaviVerma@gmail.com', '$2y$10$IaweTT/z5LOBMM0VWvBrLO1f8vTGn3c0VmLfWXq.nIaCk7q96Z2lC', '9876543216', 'Pediatrics', 'MBBS, MD', 'male', 'BMDC12348', '126 Main St'),
(5, 'Anil Chauhan', 'AnilChauhan@gmail.com', '$2y$10$e7UxkA/EBoT1GMt43XQlP.GFIUbA1GF1yUqMXa4P/NqjM5vUEH9Qe', '9876543218', 'General Surgery', 'MBBS, MS', 'male', 'BMDC12349', '127 Main St'),
(6, 'vikram hegde', 'vikram@gmail.com', '$2y$10$UY5fxdDLjv4Q4K8svPpqiurxg4J76x5VXgRP5teJJ7p/c60HWzjj6', '9449050564', 'dentist', 'MBBS,MD', 'male', 'BMDC126853', 'banglore karnataka');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `submit_date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `req_doctors`
--

CREATE TABLE `req_doctors` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `qualifications` varchar(255) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `BMDC_reg_num` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temporary_appointments`
--

CREATE TABLE `temporary_appointments` (
  `temp_appointment_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `request_time` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `temporary_appointments`
--

INSERT INTO `temporary_appointments` (`temp_appointment_id`, `doctor_id`, `user_id`, `request_time`, `status`) VALUES
(1, 1, 2, '2024-06-17', 'approved'),
(2, 1, 2, '2024-06-17', 'approved'),
(3, 2, 11, '2024-06-27', 'approved'),
(4, 1, 11, '2024-06-19', 'approved'),
(5, 1, 11, '2024-06-11', 'denied');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `phone_number`, `address`, `gender`) VALUES
(1, 'AmitPatel', '$2y$10$3Um28bUrA5ZhXf2QYhLmIOZRIneOM7xcudb63fZovot/SMVlsOBK2', 'AmitPatel@gmail.com', '9876543210', '123 Main St', 'male'),
(2, 'SunitaSharma', '$2y$10$68KKVBQ84G/DQdNbqZG/rukJBPjDQXNV5BUOwS9Jn4xDloZCk3XGa', 'SunitaSharma@gmail.com', '9876543211', '123 Main St', 'female'),
(3, 'RajeshKumar', '$2y$10$ZNCBosY6isCKZvzjCK0K6.cn1huqDgJOEjzE1n4GGZN0cLYhKl2/W', 'RajeshKumar@gmail.com', '9876543212', '123 Main St', 'male'),
(4, 'PriyaSingh', '$2y$10$v936lraAGV4xqevnrS2xZekBtPoLTF3T.//xEsZY6tpEOItekhteG', 'PriyaSingh@gmail.com', '9876543213', '123 Main St', 'female'),
(5, 'VijayReddy', '$2y$10$hx0Vbp0fXoPXXiJLwCH/i.cn5TBolLOx3NgeQ.TsWpmCsulTQmydK', 'VijayReddy@gmail.com', '9876543214', '123 Main St', 'male'),
(6, 'NehaGupta', '$2y$10$0wnEfagwsHIqVj4.yN2Me./oIwfbNXCDDEF4CTabFE8wA/pcehqt.', 'NehaGupta@gmail.com', '9876543215', '123 Main St', 'female'),
(8, 'PoojaNair', '$2y$10$P/HfJ1r4hDtw/Vb5uYiDt.Io43t5iaP1jIoN9dQvGRgXWXS35S2Mu', 'PoojaNair@gmail.com', '9876543217', '123 Main St', 'female'),
(10, 'DivyaBhatia', '$2y$10$02D.Vq89LYATx2LeQf8NAemklGd0ohseA9LumYI/meXHGOtxUzRl2', 'DivyaBhatia@gmail.com', '9876543219', '123 Main St', 'female'),
(11, 'vikram hegde', '$2y$10$hfHCuqk0C/eq8kzCwBjiz.SE7MxTyBaAksPNvZ0AM.XKe5ElXQAQC', 'vikram@gmail.com', '9449050564', 'banglore India', 'male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `denied_appointments`
--
ALTER TABLE `denied_appointments`
  ADD PRIMARY KEY (`denied_appointment_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `req_doctors`
--
ALTER TABLE `req_doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `temporary_appointments`
--
ALTER TABLE `temporary_appointments`
  ADD PRIMARY KEY (`temp_appointment_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `denied_appointments`
--
ALTER TABLE `denied_appointments`
  MODIFY `denied_appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `req_doctors`
--
ALTER TABLE `req_doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `temporary_appointments`
--
ALTER TABLE `temporary_appointments`
  MODIFY `temp_appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `denied_appointments`
--
ALTER TABLE `denied_appointments`
  ADD CONSTRAINT `denied_appointments_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  ADD CONSTRAINT `denied_appointments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `temporary_appointments`
--
ALTER TABLE `temporary_appointments`
  ADD CONSTRAINT `temporary_appointments_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  ADD CONSTRAINT `temporary_appointments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
