<?php
include '../includes/config.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background-image: url('../includes/images/bg_1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            backdrop-filter: blur(10px);
            min-height: 100vh;
        }
    </style>
    <title>Dashboard</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container" style="margin-top: 100px;">
        <div class="row">

            <?php
            $sql = "Select * from doctors";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-6">
                <div class="card shadow mb-5 p-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Doctors</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="./doctor_manage.php#manage" class="btn btn-dark">Manage Doctors</a>
                    </div>
                </div>
            </div>

            <?php
            $sql = "Select * from req_doctors";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-6">
                <div class="card shadow mb-5 p-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">New Doctor Approvals</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="./doctor_manage.php#approvals" class="btn btn-dark">See Requests</a>
                    </div>
                </div>
            </div>

        </div>

        <div class="row">


            <?php
            $sql = "Select * from users";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-6">
                <div class="card shadow mb-5 p-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Users</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="./user_manage.php#manage" class="btn btn-dark">Manage Users</a>
                    </div>
                </div>
            </div>

            <?php
            $sql = "Select * from message";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-6">
                <div class="card shadow mb-5 p-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Messages</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="./messages.php" class="btn btn-dark">See All</a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php include './includes/footer.php'; ?>
</body>

</html>