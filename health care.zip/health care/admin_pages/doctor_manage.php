<?php
include '../includes/config.php';
$uid = $_SESSION['uid'];

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $new_pass = $_POST['new_pass'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $specialization = $_POST['specialization'];
    $qualifications = $_POST['qualifications'];
    $BMDC_reg_num = $_POST['BMDC_reg_num'];

    $hash_password = password_hash($new_pass, PASSWORD_DEFAULT);

    $sql = "INSERT INTO `doctors`( `fullname`,  `email`, `password`, `phone`, `specialization`, `qualifications`, `gender`, `BMDC_reg_num`, `address`) VALUES ('$username','$email','$hash_password','$phone','$specialization','$qualifications','$gender','$BMDC_reg_num','$address')";

    $result = $conn->query($sql);
    if ($result) {
        header("Location: ./doctor_manage.php");
    } else {
        $message = "Error : " . $conn->error;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container mb-5" style="margin-top: 100px;">
        <div class="row">

            <?php
            $sql = "Select * from req_doctors";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-4">
                <div class="card shadow mb-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">New Doctor Approvals</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="#approvals" class="btn btn-dark">See Requests</a>
                    </div>
                </div>
            </div>


            <?php
            $sql = "Select * from doctors";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-4">
                <div class="card shadow mb-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Doctors</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="#manage" class="btn btn-dark">Manage</a>
                    </div>
                </div>
            </div>


            <div class="col-md-4">
                <div class="card shadow mb-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Add New Doctor</h5>
                        <p class="card-text">Add a new doctors information manually.</p>
                        <a href="#reg_form" class="btn btn-dark">Registration form</a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="container mb-5" id="approvals">
        <div class="row">
            <h3 class="text-center">New Doctors registration approvals</h3>
        </div>
        <hr>

        <?php
        $sql = "SELECT * from req_doctors";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) :
        ?>
            <div class="row">
                <table class="table">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Specialization</th>
                            <th scope="col">Qualification</th>
                            <th scope="col">BMDC regno</th>
                            <th scope="col">Address</th>
                            <th scope="col">Handle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        while ($data = $result->fetch_assoc()) :
                        ?>

                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td><?php echo $data['fullname']; ?></td>
                                <td><?php echo $data['email']; ?></td>
                                <td><?php echo $data['phone']; ?></td>
                                <td><?php echo $data['specialization']; ?></td>
                                <td><?php echo $data['qualifications']; ?></td>
                                <td><?php echo $data['BMDC_reg_num']; ?></td>
                                <td><?php echo $data['address']; ?></td>
                                <td>
                                    <a href="./includes/approve.php?id=<?php echo $data['id']; ?>"><button class="btn btn-success">Approve</button></a>
                                    <a href="./includes/reject.php?id=<?php echo $data['id']; ?>"><button class="btn btn-warning">Reject</button></a>
                                </td>
                            </tr>
                        <?php endwhile; ?>

                    </tbody>
                </table>
            </div>
        <?php else : ?>
            <h3 class="text-center">No new registration Requests</h3>
        <?php endif; ?>
        <hr>
    </div>

    <div class="container" id="manage">
        <div class="row">
            <h3 class="text-center">Doctors Management</h3>
        </div>
        <hr>

        <?php
        $sql = "SELECT * from doctors";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) :
        ?>
            <div class="row">
                <table class="table">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">Doctor ID</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Specialization</th>
                            <th scope="col">Qualification</th>
                            <th scope="col">BMDC regno</th>
                            <th scope="col">Address</th>
                            <th scope="col">Handle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($data = $result->fetch_assoc()) :
                        ?>

                            <tr>
                                <th scope="row"><?php echo $data['id']; ?></th>
                                <td><?php echo $data['fullname']; ?></td>
                                <td><?php echo $data['email']; ?></td>
                                <td><?php echo $data['phone']; ?></td>
                                <td><?php echo $data['specialization']; ?></td>
                                <td><?php echo $data['qualifications']; ?></td>
                                <td><?php echo $data['BMDC_reg_num']; ?></td>
                                <td><?php echo $data['address']; ?></td>
                                <td><button id="<?php echo $data['id']; ?>" class="btn btn-warning remove">Remove</button></a></td>
                            </tr>
                        <?php endwhile; ?>

                    </tbody>
                </table>
            </div>
        <?php else : ?>
            <h3 class="text-center">No doctors found</h3>
        <?php endif; ?>
    </div>

    <div class="container shadow p-3 mb-5 bg-body rounded" id="reg_form" style="min-width: 360px;width:50%;margin-top:100px">
        <h5 class="text-center nav-pills nav-fill">
            <div class="nav-item">
                <div class="nav-link active bg-dark">Doctor Register</div>
            </div>
        </h5>
        <form action="" method="post" style="display: flex;flex-direction:column;">
            <div class="mb-3">
                <label for="exampleInputText" class="form-label">Fullname</label>
                <input type="text" name="username" class="form-control" id="exampleInputText" aria-describedby="textHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Phone number</label>
                <input type="number" name="phone" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Specialization</label>
                <input type="text" name="specialization" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Qualifications</label>
                <textarea class="form-control" name="qualifications" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">BMDC registration number</label>
                <input type="text" name="BMDC_reg_num" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="">Gender</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1" checked value="male">
                    <label class="form-check-label" for="flexRadioDefault1">
                        Male
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="female">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Female
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="other">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Other
                    </label>
                </div>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Create new password</label>
                <input type="password" name="new_pass" class="form-control" id="exampleInputPassword1">
            </div>

            <button type="submit" class="btn btn-dark" style="align-self: center;">Register</button>
        </form>
    </div>

    <?php include './includes/footer.php'; ?>
    <script>
        removeBtn = document.querySelectorAll('.remove');
        removeBtn.forEach(element => {
            element.onclick = function() {
                if (confirm("Are you sure to remove doctor with ID : " + element.id)) {
                    window.location.href = "./includes/remove_doctor.php?id=" + element.id;
                }
            }
        });
    </script>
</body>

</html>