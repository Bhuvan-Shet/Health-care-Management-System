<?php
include '../includes/config.php';


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container mb-5" style="margin-top: 100px;">
        <div class="row">

            <?php
            $sql = "Select * from users";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-4">
                <div class="card shadow mb-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Users</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="#manage" class="btn btn-dark">Manage Users</a>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <div class="container" id="manage">
        <h3 class="text-center">Manage Users</h3>
        <hr>
        <div class="row">

            <?php
            $sql = "SELECT * from users";
            $result = $conn->query($sql);
            if ($result) :
            ?>
                <table class="table">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">UserID</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Address</th>
                            <th scope="col">Handle</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php
                        while ($data = $result->fetch_assoc()) :
                        ?>
                            <tr>
                                <th scope="row"><?php echo $data['id']; ?></th>
                                <td><?php echo $data['username']; ?></td>
                                <td><?php echo $data['email']; ?></td>
                                <td><?php echo $data['phone_number']; ?></td>
                                <td><?php echo $data['gender']; ?></td>
                                <td><?php echo $data['address']; ?></td>
                                <td><button class="btn btn-warning remove" id="<?php echo $data['id']; ?>">Remove</button></td>
                            </tr>
                        <?php endwhile; ?>

                    </tbody>
                </table>
            <?php
            endif;

            ?>
        </div>
    </div>

    <?php include './includes/footer.php'; ?>
    <script>
        removeBtn = document.querySelectorAll('.remove');
        removeBtn.forEach(element => {
            element.onclick = function() {
                if (confirm("Are you sure to remove user with ID : " + element.id)) {
                    window.location.href = "./includes/remove_user.php?id=" + element.id;
                }
            }
        });
    </script>
</body>

</html>