<?php

include '../../includes/config.php';

$id = $_GET['id'];

$sql = "Delete from users where id  ='$id'";
$res = $conn->query($sql);
if ($res) {
    header("Location: ../user_manage.php");
} else {
    echo "Error : " . $conn->error;
}
