<?php
include '../../includes/config.php';

$id = $_GET['id'];

$sql = "DELETE from message where id = '$id'";
$result = $conn->query($sql);
if ($result) {
    header("Location: ../messages.php");
} else {
    echo "Error : " . $conn->error;
}
