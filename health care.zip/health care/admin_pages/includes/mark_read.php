<?php

include '../../includes/config.php';

$id = $_GET['id'];

$sql = "UPDATE message set status = 'read' where id = '$id'";
$result = $conn->query($sql);
if ($result) {
    header("Location: ../messages.php");
} else {
    echo "Error : " . $conn->error;
}
