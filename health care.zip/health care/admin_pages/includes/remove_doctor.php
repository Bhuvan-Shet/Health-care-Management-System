<?php

include '../../includes/config.php';

$id = $_GET['id'];

$sql = "Delete from doctors where id  ='$id'";
$res = $conn->query($sql);
if ($res) {
    header("Location: ../doctor_manage.php");
} else {
    echo "Error : " . $conn->error;
}
