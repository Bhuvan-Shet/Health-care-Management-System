<div class="container p-0" id="footer" style="max-width: 100% !important;">
    <footer class="footer p-4" id="contactUs" style="background-color: rgba(0, 0, 0, 0.7);">
        <div class="container text-light">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h5>Contact Information</h5>
                    <hr>
                    <p><i class="fa fa-map-marker" style="width:30px"></i>123 Yelahanka ,Banglore-123456</p>
                    <p><i class="fa fa-envelope" style="width:30px"></i>Email: info@healthcareapp.com</p>
                    <p><i class="fa fa-phone" style="width:30px"></i>Phone: +91 123456789</p>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12 text-center">
                    Copyright&copy;2024 | Created at <a href="https://zetacoding.com">Zetacoding Innovative Solutions.</a>
                </div>
            </div>
        </div>
    </footer>
</div>