<?php
include '../includes/config.php';


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages</title>
</head>

<body>
    <?php include  './includes/header.php' ?>

    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <?php
            $sql = "Select * from message";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-4">
                <div class="card shadow mb-5 p-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">Total Messages</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="#list" class="btn btn-dark">See All</a>
                    </div>
                </div>
            </div>

            <?php
            $sql = "Select * from message where status = 'unread'";
            $result = $conn->query($sql);
            $num = $result->num_rows;
            ?>
            <div class="col-md-4">
                <div class="card shadow mb-5 p-5">
                    <div class="card-body text-center">
                        <h5 class="card-title">New Messages</h5>
                        <p class="card-text fs-2"><?php echo $num; ?></p>
                        <a href="#manage" class="btn btn-dark">Manage</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    $sql = "SELECT * from message order by status desc";
    $result = $conn->query($sql);
    ?>
    <div class="container mt-5">
        <h1 class="text-center">Admin Messages</h1>
        <div class="row mt-4">
            <?php
            if ($result->num_rows > 0) :
                while ($data = $result->fetch_assoc()) : ?>

                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $data['name']; ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted"><?php echo $data['email']; ?></h6>
                                <p class="card-text"><?php echo $data['message']; ?></p>
                                <p class="card-text"><small class="text-muted">Status : <?php echo $data['status']; ?></small></p>
                                <div class="mb-3">
                                    <?php if ($data['status'] == 'unread') : ?><a href="./includes/mark_read.php?id=<?php echo $data['id']; ?>"><button class="btn btn-success">Mark as read</button></a> <?php endif; ?>
                                    <a href="./includes/delete_msg.php?id=<?php echo $data['id']; ?>"><button class="btn btn-danger">Delete</button></a>
                                </div>
                            </div>
                        </div>
                    </div>

            <?php
                endwhile;
            endif;
            ?>
        </div>
    </div>



    <?php include  './includes/footer.php' ?>
</body>

</html>