--------------Healthcare Project----------------------
How to run the program.

# install xampp server if not installed.

# open "htdocs" folder in xampp server installed folder.

# Unzip the file and place "health care" folder inside "htdocs".

# start the apache,mysql servers in xampp.

# navigate to the project by opening the browser and enter address "localhost/ #folder_name# /".

# Example : if the folder name is "charity and donation" the address will be "localhost/health care/".

# Note: check database manual before running the project otherwise it may give you errors.

------------Default Users added by project creator----------

------------users credentials-----------------

username : AmitPatel
email : AmitPatel@gmail.com
password : AmitPatel

username : SunitaSharma
email : SunitaSharma@gmail.com
password : SunitaSharma

--------Admin credentials-----------------

adminName : admin
email : admin@gmail.com
password : admin

--------Doctor credentials-----------------

doctorName : Amit Patel
email : AmitPatel@gmail.com
password : Amit Patel

doctorName : Rajesh Kumar
email : RajeshKumar@gmail.com
password : Rajesh Kumar

----------------Informations and Notes -------------------------------

# /use_pages contains user pages after a user logged in.

# /doctor_pages contains doctor pages after a doctor logged in.

# /admin_pages contains admin pages after a admin logged in.

# /includes contains configuration file any changes for database connection should be made there.

# /DATABASE cointains the database file. Read database README.md file for more information.

# You can see different doctors or users registered in database while logging in you can use any email and password will be username or doctor name in the database
