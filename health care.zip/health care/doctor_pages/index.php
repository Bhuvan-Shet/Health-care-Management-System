<?php
include '../includes/config.php';
$id = $_SESSION['uid'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background-image: url('../includes/images/bg_1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            backdrop-filter: blur(10px);
            min-height: 100vh;
        }

        #footer {
            position: absolute;
            bottom: 0;
        }
    </style>
    <title>Home</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container" style="margin-top: 100px;">
        <div class="row">

            <?php
            $sql = "SELECT * from temporary_appointments where doctor_id = '$id' and status = 'pending'";
            $res = $conn->query($sql);
            $number = $res->num_rows;
            ?>
            <div class="col-md-6">
                <div class="card shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card-body" style="display: flex;flex-direction:column;align-items:center;">
                        <p class="card-text fs-4">Appointment request</p>
                        <h5 class="card-title fs-4"><?php echo $number; ?></h5>
                        <a href="./appointment_list.php" class="btn btn-dark">Appointment list</a>
                    </div>
                </div>
            </div>

            <?php
            $sql = "SELECT * from appointments where doctor_id = '$id' and status = 'pending'";
            $res = $conn->query($sql);
            $number = $res->num_rows;
            ?>
            <div class="col-md-6">
                <div class="card shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card-body" style="display: flex;flex-direction:column;align-items:center;">
                        <p class="card-text fs-4">Upcoming Appointments</p>
                        <h5 class="card-title fs-4"><?php echo $number; ?></h5>
                        <a href="./schedule.php" class="btn btn-dark">Schedule</a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php include './includes/footer.php'; ?>
</body>

</html>