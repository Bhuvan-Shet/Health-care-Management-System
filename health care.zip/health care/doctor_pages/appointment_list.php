<?php

include '../includes/config.php';
$uid = $_SESSION['uid'];

$sql = "SELECT * from temporary_appointments where doctor_id = '$uid' and status = 'pending'";
$result = $conn->query($sql);

$number = $result->num_rows;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card-body" style="display: flex;flex-direction:column;align-items:center;">
                        <p class="card-text fs-4">Appointment request</p>
                        <h5 class="card-title fs-4"><?php echo $number; ?></h5>
                        <a href="#" class="btn btn-dark">See schedule</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <h3 class="text-center mb-4">Appointment Requests</h3>
        <table class="table">
            <thead class="table-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Patient Name</th>
                    <th scope="col">Date</th>
                    <th scope="col">Handle</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT users.username as uname, temporary_appointments.temp_appointment_id as a_id,temporary_appointments.request_time as req_time from temporary_appointments join users on users.id = temporary_appointments.user_id where temporary_appointments.doctor_id = '$uid' and status = 'pending'";
                $result = $conn->query($sql);
                if ($result) :
                    $i = 1;
                    while ($data = $result->fetch_assoc()) :
                ?>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td><?php echo $data['uname']; ?></td>
                            <td><?php echo $data['req_time']; ?></td>
                            <td style="display:inline-block">
                                <a href="./includes/approve.php?id=<?php echo $data['a_id']; ?>&time=<?php echo $data['req_time']; ?>"><button class="btn btn-success">Approve</button></a>
                                <a href="./includes/deny.php?id=<?php echo $data['a_id']; ?>"><button class="btn btn-warning">Deny</button></a>
                            </td>
                        </tr>
                <?php
                    endwhile;
                endif;
                ?>

            </tbody>
        </table>
    </div>

    <?php include './includes/footer.php'; ?>
</body>

</html>