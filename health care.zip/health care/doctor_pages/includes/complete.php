<?php

include '../../includes/config.php';

$id = $_GET['id'];

$sql = "UPDATE appointments set status = 'completed' where appointment_id = '$id'";
$res = $conn->query($sql);
if ($res) {
    header("Location: ../schedule.php");
} else {
    echo $conn->error;
}
