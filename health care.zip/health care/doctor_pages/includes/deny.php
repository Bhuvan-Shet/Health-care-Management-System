<?php

include '../../includes/config.php';

$id = $_GET['id'];
$time = $_GET['time'];

$sql = "CALL DenyAppointment('$id', 'Doctor is unavailable at the requested time.');";
$result = $conn->query($sql);

if ($result) {
    header("Location: ../appointment_list.php");
}
