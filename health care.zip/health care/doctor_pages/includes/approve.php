<?php

include '../../includes/config.php';

$id = $_GET['id'];
$time = $_GET['time'];

$sql = "CALL ApproveAppointment('$id', '$time');";
$result = $conn->query($sql);

if ($result) {
    header("Location: ../appointment_list.php");
}
