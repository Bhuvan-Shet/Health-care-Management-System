<?php
include './includes/config.php';

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $new_pass = $_POST['new_pass'];
    $conf_pass = $_POST['conf_pass'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    if ($new_pass == $conf_pass) {
        $hash_password = password_hash($new_pass, PASSWORD_DEFAULT);
        $sql = "INSERT INTO `users`( `username`, `password`, `email`, `phone_number`, `address`, `gender`) VALUES ('$username','$hash_password','$email','$phone','$address','$gender')";

        $result = $conn->query($sql);
        if ($result) {
            header("Location: ./login.php");
        } else {
            $message = "Error : " . $conn->error;
        }
    } else {
        $message = "Passwords are not matched";
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background-image: url('./includes/images/bg_1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            backdrop-filter: blur(10px);
            min-height: 100vh;
        }
    </style>
    <title>Register</title>
</head>

<body>
    <?php include './includes/header.php' ?>

    <div class="container shadow p-3 mb-5 bg-body rounded" style="width: 360px;margin-top:100px">
        <h3 class="text-center nav-pills nav-fill">
            <div class="nav-item">
                <div class="nav-link active bg-dark">Register</div>
            </div>
        </h3>
        <form action="" method="post" style="display: flex;flex-direction:column;">
            <div class="mb-3">
                <label for="exampleInputText" class="form-label">Fullname</label>
                <input type="text" name="username" class="form-control" id="exampleInputText" aria-describedby="textHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Phone number</label>
                <input type="number" name="phone" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="">Gender</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1" checked value="male">
                    <label class="form-check-label" for="flexRadioDefault1">
                        Male
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="female">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Female
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="other">
                    <label class="form-check-label" for="flexRadioDefault2">
                        Other
                    </label>
                </div>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Create new password</label>
                <input type="password" name="new_pass" class="form-control" id="exampleInputPassword1">
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Confirm password</label>
                <input type="password" name="conf_pass" class="form-control" id="exampleInputPassword1">
            </div>

            <button type="submit" class="btn btn-dark" style="align-self: center;">Register</button>

            <div class="text-center" style="margin-top: 10px;">
                <p>Are you a doctor? <a href="./register_doctor.php">Register here</a></p>
            </div>

            <div class="text-center" style="margin-top: 10px;">
                <p>Already have an account? <a href="./login.php">Login</a></p>
            </div>
        </form>
    </div>

    <?php include './includes/footer2.php' ?>

</body>

</html>