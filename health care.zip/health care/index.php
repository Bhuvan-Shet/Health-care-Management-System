<?php
include './includes/config.php';

$message = "";
$success = false;
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $sql = "INSERT into message (name,email,message) values ('$name','$email','$message')";
    $result = $conn->query($sql);
    if ($result) {
        $message = "Submitted successfully.";
        $success = true;
    } else {
        $message = "Error in submitting your query";
        $success = false;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" style="max-height: 500px;overflow:hidden">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="./includes/images/carousel-1.jpg" class="d-block w-100" alt="Image">
            </div>
            <div class="carousel-item">
                <img src="./includes/images/carousel-2.jpg" class="d-block w-100" alt="Image">
            </div>
            <div class="carousel-item">
                <img src="./includes/images/carousel-3.jpg" class="d-block w-100" alt="Image">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <div class="container" style="margin-top: 50px;">
        <p class="fs-4">Welcome to HealthConnect, your trusted source for reliable and up-to-date healthcare information. At HealthConnect, we are dedicated to providing you with comprehensive, evidence-based medical knowledge to empower you in making informed health decisions. Our expert-reviewed articles cover a wide range of topics including disease prevention, treatment options, mental health, nutrition, and wellness tips. Whether you're seeking advice on managing chronic conditions, looking for healthy lifestyle tips, or exploring the latest medical advancements, HealthConnect is here to guide you. Our user-friendly interface ensures easy navigation, while our commitment to accuracy and clarity ensures you receive the best possible information. Join our community to stay informed, stay healthy, and stay connected. At HealthConnect, your health and well-being are our top priorities</p>
    </div>

    <?php include './includes/footer.php' ?>
</body>

</html>