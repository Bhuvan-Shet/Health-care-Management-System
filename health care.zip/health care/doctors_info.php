<?php
include './includes/config.php';

if (isset($_GET['filter'])) {
    $filter = $_GET['filter'];
    echo $filter;
    $sql = "SELECT fullname,specialization,qualifications from doctors where specialization = '$filter'";
} else {
    $sql = "SELECT fullname,specialization,qualifications from doctors";
}

$result = $conn->query($sql);
if (!$result) echo $conn->error;

$sql2 = "SELECT DISTINCT specialization FROM doctors";
$result2 = $conn->query($sql2);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctors Available</title>
</head>

<body>
    <?php include './includes/header.php' ?>


    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-8 text-center">
                <h3>All available doctors</h3>
            </div>
            <div class="col-md-2">
                <p class="text-end">Filter by</p>
            </div>
            <div class="col-md-2">
                <form action="" method="get">
                    <select class="form-select" name="filter" aria-label="Default select example">
                        <option selected>Filter</option>
                        <?php
                        if ($result2) {
                            while ($data = $result2->fetch_assoc()) {
                                $line = '<option value="' . $data['specialization'] . '">' . $data['specialization'] . '</option>';
                                echo $line;
                            }
                        }
                        ?>
                    </select>
                </form>
            </div>
        </div>
    </div>

    <div class="container" style="margin-top: 20px;">
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Specialization</th>
                    <th scope="col">Qualifications</th>
                </tr>
            </thead>

            <?php
            if ($result) :
                $i = 1;
                while ($data = $result->fetch_assoc()) :
            ?>

                    <tbody>
                        <tr>
                            <th scope="row"><?php echo $i++; ?></th>
                            <td><?php echo $data['fullname']; ?></td>
                            <td><?php echo $data['specialization']; ?></td>
                            <td><?php echo $data['qualifications']; ?></td>
                        </tr>
                    </tbody>
            <?php
                endwhile;
            endif;
            ?>
        </table>
    </div>

    <?php include './includes/footer2.php' ?>

    <script>
        let filter = document.querySelector('.form-select');
        filter.onchange = function() {
            window.location.href = "./doctors_info.php?filter=" + filter.value;
        }
    </script>

</body>

</html>