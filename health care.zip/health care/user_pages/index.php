<?php
include '../includes/config.php';
$uid = $_SESSION['uid'];

//Update for expired appointments
$update_database = "CALL UpdateExpiredAppointments()";
$res_update = $conn->query($update_database);

$sql = "SELECT * from appointments where user_id = '$uid' and status = 'pending'";
$result = $conn->query($sql);
$number = $result->num_rows;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background-image: url('../includes/images/bg_1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            backdrop-filter: blur(10px);
            min-height: 100vh;
        }

        #footer {
            position: absolute;
            bottom: 0;
        }
    </style>
    <title>User Home</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container " style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body" style="display: flex;flex-direction:column;align-items:center;">
                        <p class="card-text fs-4">Upcoming appointments</p>
                        <h5 class="card-title fs-4"><?php echo $number; ?></h5>
                        <a href="./appointment_list.php" class="btn btn-dark">See schedule</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8"></div>
        </div>
    </div>

    <?php include './includes/footer.php'; ?>
</body>

</html>