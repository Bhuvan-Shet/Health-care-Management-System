<?php
include '../includes/config.php';

$uid = $_SESSION['uid'];
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $old_pass = $_POST['old_pass'];
    $new_pass = $_POST['new_pass'];
    $conf_pass = $_POST['conf_pass'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];


    if ($old_pass != null and $new_pass != null and $conf_pass != null) {
        if ($new_pass == $conf_pass) {
            $sql = "SELECT password from users where id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $uid);
            $stmt->execute();
            $stmt->bind_result($hashed_pass);
            $stmt->fetch();
            $stmt->close();
            if (password_verify($old_pass, $hashed_pass)) {
                $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
                $sql2 = "UPDATE `users` SET `username`='$username',`password`='$hashed_pass',`email`='$email',`phone_number`='$phone',`address`='$address',`gender`='$gender' WHERE id = '$uid'";
            } else {
                $message = "Incorrect old password.";
            }
        } else {
            $message = "New passwords do not match";
        }
    } else {
        $sql2 = "UPDATE `users` SET `username`='$username',`email`='$email',`phone_number`='$phone',`address`='$address',`gender`='$gender' WHERE id = '$uid'";
    }
    $update_res = $conn->query($sql2);
}

$sql = "SELECT * from users where id = '$uid'";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
</head>

<body>

    <?php include './includes/header.php'; ?>

    <?php
    if ($result) :
        while ($data = $result->fetch_assoc()) :
    ?>

            <div class="container shadow p-3 mb-5 bg-body rounded" style="width: 360px;margin-top:100px">
                <h3 class="text-center">Profile</h3>
                <form action="" method="post" style="display: flex;flex-direction:column;">
                    <div class="mb-3">
                        <label for="exampleInputText" class="form-label">Fullname</label>
                        <input type="text" name="username" class="form-control" id="exampleInputText" value="<?php echo $data['username']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" name="email" class="form-control" id="exampleInputEmail1" value="<?php echo $data['email']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Phone number</label>
                        <input type="text" name="phone" class="form-control" id="exampleInputEmail1" value="<?php echo $data['phone_number']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                        <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3"><?php echo $data['address']; ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="">Gender</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1" value="male" <?php if ($data['gender'] == "male")  echo "checked"; ?>>
                            <label class="form-check-label" for="flexRadioDefault1">
                                Male
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="female" <?php if ($data['gender'] == "female")  echo "checked"; ?>>
                            <label class="form-check-label" for="flexRadioDefault2">
                                Female
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault2" value="other" <?php if ($data['gender'] == "other")  echo "checked"; ?>>
                            <label class="form-check-label" for="flexRadioDefault2">
                                Other
                            </label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Old password</label>
                        <input type="password" name="old_pass" class="form-control" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Create new password</label>
                        <input type="password" name="new_pass" class="form-control" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Confirm new password</label>
                        <input type="password" name="conf_pass" class="form-control" id="exampleInputPassword1">
                    </div>
                    <p class="text-warning"><?php echo $message; ?></p>
                    <div class="mb-3" style="display: flex;justify-content:space-between;">
                        <button type="submit" class="btn btn-primary" style="align-self: center;">Update</button>
                        <button type="button" class="btn btn-dark cancel_btn" style="align-self: center;">Cancel</button>
                    </div>
                </form>
            </div>

    <?php
        endwhile;
    else :
        echo $conn->error;
    endif;
    ?>

    <?php include './includes/footer.php'; ?>

    <script>
        document.querySelector(".cancel_btn").onclick = function() {
            window.location.href = "./index.php";
        }
    </script>

</body>

</html>