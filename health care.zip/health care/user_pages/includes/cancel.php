<?php

include '../../includes/config.php';
$id = $_GET['id'];

$sql = "DELETE from temporary_appointments where temp_appointment_id = '$id'";
$res = $conn->query($sql);
if ($res)
    header("Location: ../appointment_list.php");
