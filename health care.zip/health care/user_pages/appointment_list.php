<?php
include '../includes/config.php';
$uid = $_SESSION['uid'];
$category_set = false;

$filter_set = false;
if (isset($_GET['filter'])) {
    $filter_set = true;
    $filter = $_GET['filter'];
}

if (isset($_GET['category'])) {
    $category_set = true;
    $specialization = $_GET['category'];
    $sql1 = "SELECT id,fullname from doctors where specialization = '$specialization'";
    $res = $conn->query($sql1);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST['doctor_id'];
    $date = $_POST['date'];
    $insert_sql = "INSERT INTO temporary_appointments(doctor_id, user_id,request_time, status) VALUES('$doctor_id','$uid','$date','pending')";
    $is_inserted = $conn->query($insert_sql);
    if ($is_inserted) {
        header("Location: ./appointment_list.php");
    }
}

$sql = "SELECT * from appointments where user_id = '$uid' and status = 'pending'";
$result = $conn->query($sql);
$number = $result->num_rows;

$sql2 = "SELECT DISTINCT specialization FROM doctors";
$result2 = $conn->query($sql2);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        ion-icon {
            font-size: 20px;
            background: red;
            padding: 10px;
            border-radius: 50%;
            margin-left: 0;
            cursor: pointer;
        }
    </style>
    <title>Appointments</title>
</head>

<body>
    <?php include './includes/header.php'; ?>

    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm p-3 mb-5 bg-body rounded">
                    <div class="card-body" style="display: flex;flex-direction:column;align-items:center;">
                        <p class="card-text fs-4">Upcoming appointments</p>
                        <h5 class="card-title fs-4"><?php echo $number; ?></h5>
                        <a href="#" class="btn btn-dark">See schedule</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="container shadow-sm p-3 mb-5 bg-body rounded">
                    <form action="" method="post">
                        <div class="mb-3">
                            <select class="form-select" name="filter" id="doctor_category" aria-label="Default select example">
                                <option <?php if (!$category_set) echo "selected"; ?>>Doctors Specialization</option>
                                <?php
                                if ($result2) {
                                    while ($data = $result2->fetch_assoc()) {
                                        if ($category_set and $data['specialization'] == $specialization)
                                            $line = '<option value="' . $data['specialization'] . '" selected>' . $data['specialization'] . '</option>';
                                        else
                                            $line = '<option value="' . $data['specialization'] . '">' . $data['specialization'] . '</option>';
                                        echo $line;
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <select class="form-select" name="doctor_id" aria-label="Default select example">
                                <option selected>Select Doctor</option>
                                <?php
                                if ($category_set) :
                                    if ($res) :
                                        while ($data = $res->fetch_assoc()) :
                                ?>
                                            <option value="<?php echo $data['id']; ?>"><?php echo $data['fullname']; ?></option>
                                <?php
                                        endwhile;
                                    else :
                                        echo $conn->error;
                                    endif;
                                endif;
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <input type="date" name="date" class="form-control" id="date_select">
                        </div>
                        <div class="mb-3">
                            <select class="form-select" aria-label="Default select example" disabled>
                                <option value="1" selected>09:30am - 06:00pm</option>
                            </select>
                        </div>
                        <div class="mb-3" style="display: flex;justify-content:center">
                            <button type="submit" class="btn btn-dark">Book appointment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="container" style="margin-top: 30px;">
        <div class="row">
            <div class="col-md-10">
                <h3 class="text-center">Manage Your appointments</h3>
            </div>
            <div class="col-md-2">
                <div class="row" style="align-items: center;">
                    <div class="col-md-10">
                        <select class="form-select" id="filter" name="filter" aria-label="Default select example">
                            <option <?php if (!$filter_set) echo "selected"; ?>>Filter</option>
                            <option value="pending" <?php if ($filter_set and $filter == 'pending') echo "selected"; ?>>Pending</option>
                            <option value="denied" <?php if ($filter_set and $filter == 'denied') echo "selected"; ?>>Denied</option>
                            <option value="expired" <?php if ($filter_set and $filter == 'expired') echo "selected"; ?>>Expired</option>
                        </select>
                    </div>
                    <?php if ($filter_set) : ?>
                        <div class="col-md-2 " style="padding-left: 0;">
                            <ion-icon class="shadow-sm bg-body rounded" name="close-outline" data-bs-toggle="tooltip" data-bs-placement="top" title="Clear Filters" onclick="clearFilter()"></ion-icon>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <hr>
        <?php
        if (!$filter_set) :
            $sql = "SELECT doctors.fullname as fullname, appointments.appointment_time as date, appointments.token_number as token from appointments join doctors on doctors.id = appointments.doctor_id where appointments.user_id = '$uid' and appointments.status = 'pending'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) :
        ?>
                <h3>Upcoming appointments</h3>
                <table class="table">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Doctor</th>
                            <th scope="col">Date</th>
                            <th scope="col">Token number</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        while ($data = $result->fetch_assoc()) :
                        ?>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td><?php echo $data['fullname']; ?></td>
                                <td><?php echo $data['date']; ?></td>
                                <td><?php echo $data['token']; ?></td>
                                <td><?php echo "Approved"; ?></td>
                            </tr>
                        <?php
                        endwhile;
                        ?>
                    </tbody>
                </table>
            <?php
            else :
            ?>
                <h3 class="text-center mb-5">No appointments Booked</h3>
        <?php
            endif;
        endif;
        ?>


        <?php
        if ($filter_set) :
            if ($filter == 'pending') :
                $sql2 = "SELECT doctors.fullname as fullname, temporary_appointments.temp_appointment_id as id, temporary_appointments.request_time as date from temporary_appointments join doctors on doctors.id = temporary_appointments.doctor_id where temporary_appointments.user_id = '$uid' and temporary_appointments.status = 'pending'";
                $result2 = $conn->query($sql2);
                if ($result2->num_rows > 0) :
        ?>
                    <h3>Pending appointments</h3>
                    <table class="table">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Doctor</th>
                                <th scope="col">Requested Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Handle</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            $i = 1;
                            while ($data = $result2->fetch_assoc()) :
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $i++; ?></th>
                                    <td><?php echo $data['fullname']; ?></td>
                                    <td><?php echo $data['date']; ?></td>
                                    <td><?php echo "Pending"; ?></td>
                                    <td><a href="./includes/cancel.php?id=<?php echo $data['id']; ?>"><button class="btn btn-warning">Cancel</button></a></td>
                                </tr>
                            <?php
                            endwhile;
                            ?>
                        </tbody>
                    </table>
                <?php
                else :
                ?>
                    <h3 class="text-center mb-5">No pending appointments</h3>
            <?php
                endif;
            endif;
            ?>

            <?php
            if ($filter == 'denied') :
                $sql2 = "SELECT doctors.fullname as fullname,  denied_appointments.request_time as date, denied_appointments.reason as reason from  denied_appointments join doctors on doctors.id =  denied_appointments.doctor_id where  denied_appointments.user_id = '$uid'";
                $result2 = $conn->query($sql2);
                if ($result2->num_rows > 0) :
            ?>
                    <h3>Denied appointments</h3>
                    <table class="table">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Doctor</th>
                                <th scope="col">Requested Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            while ($data = $result2->fetch_assoc()) :
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $i++; ?></th>
                                    <td><?php echo $data['fullname']; ?></td>
                                    <td><?php echo $data['date']; ?></td>
                                    <td><?php echo "Denied"; ?></td>
                                    <td><?php echo $data['reason']; ?></td>
                                </tr>
                            <?php
                            endwhile;
                            ?>
                        </tbody>
                    </table>
                <?php
                else :
                ?>
                    <h3 class="text-center mb-5">No Denied appointments</h3>
            <?php
                endif;
            endif;
            ?>

            <?php
            if ($filter == 'expired') :
                $sql3 = "SELECT doctors.fullname as fullname, appointments.appointment_time as date, appointments.token_number as token from appointments join doctors on doctors.id = appointments.doctor_id where appointments.user_id = '$uid' and appointments.status = 'expired'";
                $result3 = $conn->query($sql3);
                if ($result3->num_rows > 0) :
            ?>
                    <h3>Expired appointments</h3>
                    <table class="table">
                        <thead class="table-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Doctor</th>
                                <th scope="col">Requested Date</th>
                                <th scope="col">Status</th>
                                <th scope="col">Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            while ($data = $result3->fetch_assoc()) :
                            ?>
                                <tr>
                                    <th scope="row"><?php echo $i++; ?></th>
                                    <td><?php echo $data['fullname']; ?></td>
                                    <td><?php echo $data['date']; ?></td>
                                    <td><?php echo "Expired"; ?></td>
                                    <td><?php echo "You have not attended the appointment." ?></td>
                                </tr>
                            <?php
                            endwhile;
                            ?>
                        </tbody>
                    </table>
                <?php
                else :
                ?>
                    <h3 class="text-center mb-5">No expired appointment</h3>
        <?php
                endif;
            endif;
        endif;
        ?>
    </div>

    <?php include './includes/footer.php'; ?>

    <script>
        let category = document.getElementById('doctor_category');
        category.onchange = function() {
            window.location.href = "./appointment_list.php?category=" + category.value;
        }
        let app_date = document.getElementById('date_select');
        date = new Date();
        year = date.getFullYear();
        month = date.getMonth();
        day = date.getDate();
        current_date = year + '-' + month + '-' + day;
        app_date.setAttribute("min", current_date);

        let filter = document.getElementById('filter');
        filter.onchange = function() {
            window.location.href = "./appointment_list.php?filter=" + filter.value;
        }

        function clearFilter() {
            window.location.href = './appointment_list.php';
        }
    </script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>

</html>